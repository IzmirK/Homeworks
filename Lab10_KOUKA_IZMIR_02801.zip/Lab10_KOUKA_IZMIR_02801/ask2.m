function ask2(t)
   
    x = [0, 4, 8, 12, 16, 20, 24];
    y = [15, 14.2, 12.8, 13.9, 17, 16.8, 15.5];

    interp1(t,y, 'linear');
    interp2(t,y, 'spline');
    
    hold on
    plot(x, y, '*black')
    plot(interp1, '-blue')
    plot(interp2, '*blue')
    plot(interp1, '-red')
    plot(interp2, '*red')
end