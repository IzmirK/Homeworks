%A
function thermokrasia = ask3(x, y, t)
    n = length(x);
    thermokrasia = 0;
    
    for i = 1:n
        L = 1;
        for j = 1:n
            if j ~= i
                L = L * (t - x(j)) / (x(i) - x(j));
            end
        end
        thermokrasia = thermokrasia + y(i) * L;
    end
end

%B
function thermokrasies = ask3b(x, y, t)
    n = length(t);
    thermokrasies = zeros(1, n);
    
    for k = 1:n
        thermokrasia = 0;
        for i = 1:length(x)
            L = 1;
            for j = 1:length(x)
                if j ~= i
                    L = L * (t(k) - x(j)) / (x(i) - x(j));
                end
            end
           thermokrasia = thermokrasia + y(i) * L;
        end
        thermokrasies(k) = thermokrasia;
    end
end