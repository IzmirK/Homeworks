function ask1(t)
 
    x = [0, 4, 8, 12, 16, 20, 24];
    y = [15, 14.2, 12.8, 13.9, 17, 16.8, 15.5];
    
    polynomial = polyval(y, t);

    hold on
    plot(polynomial, '-blue')
    plot(t, '*red')
    plot(x, y, 'o black')
    hold off
   
 
    
    
    
   