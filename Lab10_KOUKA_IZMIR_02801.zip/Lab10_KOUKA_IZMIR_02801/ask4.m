% A

x = linspace(-5, 5, 100); 
y = linspace(-2*pi, 2*pi,100); 

[X, Y] = meshgrid(x, y);

Z = Y ./ (1 + X.^2 + Y.^2);

meshc(X,Y,Z);
colorbar;


%B
x2 = linspace(-2, 2, 100);
y2 = linspace(-1, 1, 100);
[X2, Y2] = meshgrid(x2, y2);
f = (1-cos(X2.^2+Y2.^2));
g = (1+sin(X2.^2+Y2.^2));
hold on
mesh(X2,Y2,f);
mesh(X2,Y2,g);
hold off


