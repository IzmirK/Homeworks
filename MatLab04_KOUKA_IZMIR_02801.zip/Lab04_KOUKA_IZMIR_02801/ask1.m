%IZMIR KOUKA 02801

%arxika orizw tous pinakes
A = [9 3 0; 3 10 3; 0 3 5];
b = [6; -1; 7];

%xrhsimopoiw th sunarthsh lu
[L,U] = lu(A);

%xrhsimopoiw tous pinakes gia na vrw to kathe x
x = (U\(L\b));
