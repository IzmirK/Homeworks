%IZMIR KOUKA 02801

function [x] = myLS( L, b )
%  Solves the system  L*x=b, where L is lower triangular matrix 

[m, n] = size(L);
if m ~= n
   error('Matrix must be square.')
end

x = zeros(n,1); % arxikopoihsh dianysmatos lyshs me katallhlh diastash

% algorithmos pros ta empros antikatastashs
x(1) = b(1) / L(1,1);
% Poia stoixeia toy x prepei na ypologis8oyn akomh kai me poia seira?
for ii=2:n % symplhrwste katallhla ta oria toy deikth ii.
    s = 0;
    for jj=1:(ii-1) % poia ypologismena stoixeia toy x lambanoyme ypopsh mas
       s = (s + L(ii,jj)*x(jj)); 
    end
    x(ii) = ((b(ii) - s)/L(ii,ii));       
end

end

