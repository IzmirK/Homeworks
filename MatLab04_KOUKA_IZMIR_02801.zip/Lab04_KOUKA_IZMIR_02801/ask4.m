%IZMIR KOUKA 02801

function [l, te1, te2] = ask4(n)

%kato trigonikon me 1 diagwnio
l = tril(magic(n), -1) + eye(n);

%dianisma b
x = ones(n,1);
b = (l * x);


ts1 = tic;
for k=1:5
  x_sol1 = myLS(l, b);
end
te1 = toc(ts1)/5;
fprintf('O xronos apo thn \\ einai  %e \n', te1);


ts2 = tic;
for k = 1:5
  x_sol2 = l\b;
end
te2 = toc(ts2)/5;
fprintf('O xronos apo thn myLS einai  %e \n', te2);


%se oles tis periptwseis to myLS einai pio grhgoro
%n = 100, myLs=0.005s /=0.013s
%n = 500, myLs=0.013s /=0.025s
%n = 1000, myLs=0.248s /=0.292s
%n = 2000, myLs=0.913s /=1.038s
