%IZMIR KOUKA 02801

%orizw tous pinakes pou tha xreiastw
A = [1 0 2; 2 -1 3; 4 1 8];
B = [0 0 -1; 1 -1 0; 1 0 -1];

invertedA = inv(A); %antistrofos A
invertedB = inv(B); %antistrofos B

X = (A * invertedB * invertedA); %ws pros X

norm_of_A = norm(A); %2h norma
cond_of_A = cond(A); %deikths katastashs
rank_of_A = rank(A); %taxh

%provoli
fprintf('Norm: %f\n', norm_of_A);
fprintf('Rank: %d\n', rank_of_A);
fprintf('Condition: %d\n', cond_of_A);