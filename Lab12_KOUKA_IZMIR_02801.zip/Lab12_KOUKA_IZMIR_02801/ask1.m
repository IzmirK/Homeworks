% pinakes x, y
x = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
y = [1.0, 2.0, 2.5, 2.3, 2.7, 3.1, 3.15, 3.16, 3.25, 3.5];

%linear least squares
linear_coef = polyfit(x, y, 1);
linear_approx = polyval(linear_coefficients, x);

%quadratic polynomial
quadratic_coef = polyfit(x, y, 2);
quadratic_approx = polyval(quadratic_coefficients, x);

%3rd order polynomial
third_order_coef = polyfit(x, y, 3);
third_order_approx = polyval(third_order_coefficients, x);

%y = ae^bx
exponential_coef = polyfit(x, log(y), 1);
exponential_approx = exp(exponential_coefficients(2)) * exp(exponential_coefficients(1) * x);

%y = (a*x)/(x+b)
saturation_coef = polyfit(x, (y.*x)./(x+1), 1);
saturation_approx = (saturation_coefficients(1)*x)./(x+saturation_coefficients(2));

plot(x, y, '*black');
hold on;
plot(x, linear_approx, '-blue')
plot(x, linear_approx, '*blue')
plot(x, quadratic_approx, '-red')
plot(x, quadratic_approx, '*red')
plot(x, exponential_approx, '-green')
plot(x, exponential_approx, '*green')
plot(x, saturation_approx, '-cyan')
plot(x, saturation_approx, '*cyan')
plot(x, third_order_approx, '-yellow')
plot(x, third_order_approx, '*yellow')
legend('data', 'Linear least squares', 'value lls', 'quadratic least squares', 'value qls', 'Exponential', 'value', 'saturation-growth-rate', 'values', '3rd order polynomial', 'values');
xlabel('x')
ylabel('y')
title('PROSEGGISH')
hold off