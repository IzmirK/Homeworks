%% H synarthsh newton ylopoiei th me8odo tou Newton gia thn 
%% eyresh ths rizas twn synarthsewn 
%% F1(X,Y) = 1-4*X+2*X.*X-2*Y.^3
%% F2(x,Y) = -4 +4*X.^4+4*Y+4*Y.^4
%% me arxikh timh to x0.
%% x0 = arxikh timh
%% tol = anoxh sto sfalma
%% maxiter = megisto plh8os synarthsewn
%% xstar = proseggish thw rizas
%% fxstar = timh ths synarthshs sth riza
%% iter = plh8os epanalhpsewn poy ektelesthkan
%%


function [xstar, fxstar, iter] = newton2(x0, tol, maxiter)
%% block kwdika poy den prepei na allaksete
global f1 f2 df1dx df1dy df2dx df2dy
%% telos block kwdika poy den prepei na allaksete

%% Oriste swsta tis synarthseis f* kai df*d* wste na doyleyoyn kai an ta x, y einai dianysmata
f1 = @(x,y) 1 - 4*x + 2*x.^2 - 2*y.^3; %% grapste toys swstous typous ths 1hs synistwsas ths f
f2 = @(x,y) -4 + 4*x.^4 + 4*y + 4*y.^4; %% grapste toys swstous typous ths 2hs synistwsas ths f

df1dx = @(x,y) -4 + 4*x; %% ypologiste kai grapste tis paragwgous opws fainetai apo ta onomata tvn metablhtvn
df1dy = @(x,y) -6*y.^2;
df2dx = @(x,y) 16*x.^3;
df2dy = @(x,y) 4 + 16*y.^3;

plot([x0(1)],[x0(2)],'k*', [x0(1)],[x0(2)],'ks');

xold = x0;
%% h fxold einai dianysma, ara sto Matlab einai dianysma stilh
%% kai periexei thn timh twn synarthsewn f* sto xold
fxold = [f1(xold(1), xold(2)) ; f2(xold(1), xold(2))];
%% DFxold einai pinakas kai periexei tis times twn 
%% parapanw paragwgwn sto xold
DFxold = [df1dx(xold(1),xold(2)) df1dy(xold(1),xold(2)) ; df2dx(xold(1),xold(2)) df2dy(xold(1),xold(2))];
    
iter = 0;

if  cond(DFxold) > 10^7
   fprintf('O pinakas me tis paragwgoys exei deikth katastashs %f sto (%f , %f) kai h me8odos Newton den mporei na synexisei.\n',cond(DFxold),xold(1), xold(2));
   xstar = xold;
   fxstar = fxold;
   return;
end

%% 1h epanalhpsh eksw apo to while loop
%% to xnew einai dianysma, ara sto Matlab einai sthlodianysma
xnew = xold - DFxold\fxold;
%% h fxnew einai dianysma, ara sto Matlab einai sthlodianysma
%% kai periexei thn timh tvn synarthsewn f* sto xnew
fxnew = [f1(xnew(1), xnew(2)) ; f2(xnew(1), xnew(2))];
iter = iter + 1;  %% ayksanetai o deikths twn epanalhpsewn

plot([xnew(1)],[xnew(2)],'m*');

while (iter < maxiter) && (norm(xnew-xold) > tol)
   xold = xnew;
   fxold = fxnew; 
   DFxold = [df1dx(xold(1),xold(2)) df1dy(xold(1),xold(2)) ; df2dx(xold(1),xold(2)) df2dy];
   if cond(DFxold) <= 10^7
      xnew = xold - DFxold \ fxold;
      fxnew = [f1(xnew(1), xnew(2)) ; f2(xnew(1), xnew(2))];
      iter = iter + 1 ;
      plot([xnew(1)],[xnew(2)],'m*');
   else
      fprintf('O pinakas me tis paragwgoys exei deikth katastashs %f sto (%f , %f) kai h me8odos Newton den mporei na synexisei.\n',cond(DFxold),xold(1), xold(2));
      xstar = xnew;
      fxstar = fxnew;
      return;
   end
end

xstar = xnew;
fxstar = [f1(xnew(1), xnew(2)) ; f2(xnew(1), xnew(2))];
plot([xstar(1)],[xstar(2)],'r*',[xstar(1)],[xstar(2)],'ro'); 
end


