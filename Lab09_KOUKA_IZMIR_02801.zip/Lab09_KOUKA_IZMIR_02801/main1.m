 
clf; clc; clear all
x = sym('x');
ekf = x^2*sin(x);
x0 = 5; %%0,  0.5,  2.3,  2.33,  5.0 ,  5.5  %%diafores arxikes times
tol = 1e-10;
maxiter = 20;
fplot(ekf, [-2*pi 2*pi]); axis tight; grid on; hold on; %axis TIGHT  sets the axis limits to the range of the data.

[xstar, fxstar, iter] = newton(x0, tol, maxiter);%evresh ths dejias rizas
if iter == 0 
  fprintf('NEWTON: H me8odos den efarmosthke.\n');
else
  fprintf('NEWTON: H riza %f vre8hke se %d epanalhpseis.\n',xstar, iter);
  if xstar < -2*pi 
     fplot(ekf, [xstar-2 2*pi]);
  elseif xstar > 2*pi
      fplot(ekf, [-2*pi xstar+2]);
  end
end

hold off;