%% H synarthsh newton ylopoiei th me8odo tou Newton gia thn 
%% eyresh ths rizas ths synarthshs f(x) = x^2*sin(x) me arxikh timh to x0.
%% H synarthsh kaleitai me [xstar, fxstar,  iter] = newton(x0, tol, maxiter)
%% opou :
%% x0 = arxikh timh
%% tol = anoxh sto sfalma
%% maxiter = megisto plh8os synarthsewn
%% xstar = proseggish thw rizas
%% fxstar = timh ths synarthshs sth riza
%% iter = plh8os epanalhpsewn poy ektelesthkan
%%


function [xstar, fxstar, iter] = newton(x0, tol, maxiter)
%% block kwdika poy den prepei na allaksete
global f df
%% telos block kwdika poy den prepei na allaksete

%% Oriste swsta tis synarthseis f kai df wste na doyleyoyn kai an ta x, y einai dianysmata
f = @(x) x.^2.*sin(x); %% h ekfrash ths x^2*sin(x) metatrepetai se synarthsh (anonymh synartish)
df = @(x) 2.*x.*sin(x) + x.^2.*cos(x);  %% h paragwgos ths synarthshs f (anonymh synartish)

plot(x0, 0,'ks'); 

xold = x0;
fxold = f(xold); %% timh ths f sto xold
dfxold = df(xold);  %% timh ths df sto xold
iter = 0;

if  abs(fxold) < tol
   fprintf('H synarthsh mhdenizetai sthn arxikh timh %f .\n',xold);
   xstar = xold;
   fxstar = fxold;
   return;
end

if  abs(dfxold) < tol
   fprintf('H paragwgos mhdenizetai sto %f kai h me8odos Newton den mporei na synexisei.\n',xold);
   xstar = xold;
   fxstar = fxold;
   return;
end

%% 1h epanalhpsh eksw apo to while loop
xnew = (xold - fxold/dfxold);  %% efarmogh ths me8odou Newton gia ypologismo 1hs proseggishs ths lyshs
fxnew = f(xnew);  %% timh ths f sto xnew
iter = iter + 1;  %% ayksanetai o deikths twn epanalhpsewn

plot(xnew, 0,'go');

while ((xnew - xold) >= (tol*xnew)) && (fxnew >= tol) && (iter < maxiter)
   xold = xnew;
   fxold = f(xold);
   dfxold = df(xold);
   if abs(dfxold) >= tol
      xnew = (xold - fxold/dfxold);
      fxnew = f(xnew);
      iter = iter + 1 ;
      plot(xnew, 0,'go');
   else
      fprintf('H paragwgos mhdenizetai sto %f kai h me8odos Newton den mporei na synexisei.\n',xold);
      xstar = xnew;
      fxstar = fxnew;
      return;
   end

end

%% block kwdika poy den prepei na allaksete
xstar = xnew;
fxstar = fxnew;
plot(xstar,0,'r*');
%% telos block kwdika poy den prepei na allaksete
end