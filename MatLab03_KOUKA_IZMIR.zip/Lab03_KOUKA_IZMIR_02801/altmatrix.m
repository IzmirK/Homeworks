% Onomateponymo::IZMIR KOUKA
% AEM::02801
% TMHMA::Tetarti 16:00-18:00

% Filename - altmatrix.m
% function - altmatrix(A)
% This function multiplies by 10 the previous of the last row
% of a given matrix A

function A = altmatrix(A)

[n, m] = size(A); %pairnw megethos tou pinaka
A(n-1, :) = (10 * (A(n-1, :))); %afou xerw megethos, xerw proteleytaia grammh, poll/zw *10

end

