% Onomateponymo::IZMIR KOUKA
% AEM::02801
% TMHMA::Tetarti 16:00-18:00

% Filename - pmatrix.m
% function - pmatrix(A)
% This function substructs the 1st row of
% a given matrix A from the other n-1 rows

function A = pmatrix(A)

[n,m] = size(A); %pairnw megethos gia na xrhsimopoihsw grammes
A(2:n, :) = A(2:n, :) - A(1, :); %apo 2h grammh mexri telous afairw 1h

end