% IZMIR KOUKA 02801
% Filename - myPlot.m
% function - myPlot(n)
% This function plots functions related to complexity

function [x, y1, y2] = myPlot(n)

x = 1:n; %apo 1 eos n
y2 = x.^2; %thelw kathe stoixeio ypsomeno
y1 = log2(x);

loglog(x, y1, 'black', x, y2, 'red');
legend('y1 = log2x', 'y2 = x^2');

end
