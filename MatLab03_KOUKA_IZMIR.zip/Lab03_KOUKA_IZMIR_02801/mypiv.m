% Onomateponymo::IZMIR KOUKA
% AEM::02801
% TMHMA::Tetarti 16:00-18:00

A = randi([1, 10], 4, 4);
P = [0 0 0 1; 0 1 0 0; 0 0 1 0; 1 0 0 0];

PA = P*A;
AP = A*P;

% Parathroume oti h 1h me thn 4h seira exoyn antimetatethei
% antistoixa kai h 1h sthlh me thn 4h sthlh.