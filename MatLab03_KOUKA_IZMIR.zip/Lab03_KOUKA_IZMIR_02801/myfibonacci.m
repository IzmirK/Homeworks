% Onomateponymo::IZMIR KOUKA
% AEM::02801
% TMHMA::Tetarti 16:00-18:00

% Filename - myfibonacci.m
% function - myfibonacci(n)
% This function returns the n-th Fibonacci number 

function fb = myfibonacci(n)

fb = zeros(1, n); %enan pinaka(gramh) me midenika arxika 
fb(2) = 1; %giati fibonacci = 0,1,1,2...
    for stoixeio = 3:n %apo to 2o stoixeio
        
        fb(stoixeio) = (fb(stoixeio-1) + fb(stoixeio-2)); %upologizw epomeno me vash ta prohgoumena 2
        
    end
end

% to apotelesma einai to idio, apla sto diko mou xekinaei 0,1,1,2,3...
% sto kanoniko fibonacci xekinaei kateutheian 1,2,3...