function [x] = lower_solve( L, b )
%  Solves the system  L*x=b, where L is lower triangular matrix 

[m, n] = size(L);
if m ~= n
   error('Matrix must be square.')
end

x = zeros(n,1);
x(1) = b(1)/L(1,1);
for ii=2:1:n
    s = 0;
    for jj=1:1:ii-1
       s = s + x(jj)*L(ii,jj); 
    end
    x(ii) = (b(ii) - s)/L(ii,ii);       
end

end

