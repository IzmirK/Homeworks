function [ x ] = lower_solve_fast( L, b )
%  Solves the system  L*x=b, where L is lower triangular matrix 
% Tropopoihste ton algorithmo etsi wste kapoia for-end loops na
% antikatasta8oun me prakseis dianysmatwn

[m, n] = size(L);
if m ~= n
   error('Matrix must be square.')
end

x = zeros(n,1);

x(1) = b(1)/L(1,1);
for k = 2:1:n
    b(k:n) = (b(k:n) - (L(k:n,k-1)*x(k-1)));
    x(k) = b(k)/L(k,k); % symplhrwste katallhla to deksi meros toy systhmatos

end

end

