function  [A, B, C] = ask3(n)
    
    A = diag(1:n);
    B = triu(ones(n),1);
    C = diag(3*ones(n,1)) + diag(4*ones(n-1,1),1) + diag(1*ones(n-1,1),-1);
    
end