function [x , y, theta] = ask4(k,n)

% Symplhrwste katallhla to arxeio wste na ikanopoiei tis apaithseis ths
% askhshs 1. 

% Ypologiste theta, x, kai y . Mhn allaksete ta onomata twn metablhtwn. 
theta = linspace(-10*pi, 10*pi, n);
x = (exp(k*theta) .* cos(theta));
y = (exp(k*theta) .* sin(theta));

% Graphics
plot(x,y)
axis equal
xlabel('$x=e^{k\theta}\cos({\theta})$', 'Interpreter', 'latex', 'FontSize', 14)
ylabel('$y=e^{k\theta}\sin({\theta})$', 'Interpreter', 'latex', 'FontSize', 14)
title('Logarithmic Spiral','Interpreter','latex','FontSize', 16)

end