function [L, U] = my_lu_fast(A)
% Square A=LU factorization.
%
% Usage: [L, U] = my_lu(A)
% INPUT:
% A         - square invertible m-by-m matrix
% OUTPUT:
% L         - square m-by-m unit lower-triangular matrix;
% U         - square m-by-m upper-triangular matrix;
% ALGORITHM:
% L and U are computed by Gaussian elimination, 
% i.e., row exchange, so that L*U=A.
%
% Examples: 
%           A = randn(5); [L,U] = my_lu_fast(A); 

[m, n] = size(A);
if m ~= n
   error('Matrix must be square.')
end
L = eye(n); % symplhrwste katallhlh arxikopoihsh toy pinaka
U = A;  % symplhrwste katallhlh arxikopoihsh toy pinaka

   
for k = 1:n
   L(k+1:n, k) = A(k+1:n, k) / A(k, k);
   A(k+1:n, k+1:n) = A(k+1:n, k+1:n) - L(k+1:n, k) * A(k, k+1:n); % ypologismos olwn twn newn stoixeiwn toy pinaka A gia th grammh i
end
U = A; %meta apo epanalhpsh o A tha periexei ta stoixeia tou U
