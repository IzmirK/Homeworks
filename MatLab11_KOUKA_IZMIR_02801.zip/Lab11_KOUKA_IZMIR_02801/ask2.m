function [coef, sfalma, h0] = ask2
clf; clear all; clc;
% peiramatika dedomena
t =[0.13 0.17 0.2 0.22 0.25 0.26 0.28 0.30 0.33 0.34]';
h =(0.1 : 0.05 : 0.55 )';

plot(t, h, '*k', 'linewidth',2); hold on
tplot = linspace(0, 0.5, 1001);

n = length(t);
A = [ones(n, 1) t];
b = h;

coef = A\b;  % ypologismos toy syntelestwn g 

hplot = coef(1) + coef(2) * tplot;  % ypologismos twn timwn thw proseggistikhs synsrthshs sta shmeia ths grafikhs parastashs 
plot(tplot, hplot, 'b-','linewidth',2);
xlabel('time')
ylabel('height')
legend('data', 'approx')

% ypologismos sfalmatos
h_proseg = coef(1) + coef(2) * t;  % ypologismos twn timwn toy polyvnymoy stis xronikes stigmes toy peiramatos
sfalma = norm(h_proseg - h) / sqrt(n); % ypologismos sfalmatos

% ypologismos arxikoy ypsous 
h0 = coef(1);
    
end