function [coef, sfalma, v0 , ac7] = ask1
clf; clear all; clc;
% peiramatika dedomena
t =(0.1:0.1:1.5)';
s =[0.2 0.95 2.15 3.95 6.25 9.1 12.4 16.2 20.55 ...
    25.35 30.6 36.3 42.65 49.15 56.4]';

plot(t,s, '*k', 'linewidth',2); hold on

tplot = linspace(0, 1.5, 1001);

coef = polyfit(t, s, degree_of_polynomial);  % ypologismos twn syntelestwn toy polyonymoy

splot = polyval(coef, tplot);  % ypologismos twn timwn toy polyvnymoy sta shmeia ths grafikhs parastashs
plot(tplot, splot, 'g-','linewidth',2);
xlabel('time')
ylabel('distance')
legend('data', 'approx')

% ypologismos sfalmatos
s_proseg = polyval(coef, t);  % ypologismos twn timwn toy polyvnymoy stis xronikes stigmes toy peiramatos
sfalma = norm(s - s_proseg); % ypologismos sfalmatos

% ypologismos arxikhs taxythtas
v0 = coef(end);


% ypologismos epitaxynshs 
ac = 2 * coef(end-1);

% ypologismos apostashs gia t=0.7 
s7 = polyval(coef, 0.7);

end