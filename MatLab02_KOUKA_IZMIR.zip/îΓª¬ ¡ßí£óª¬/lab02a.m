%Grafima synartishs
%IZMIR KOUKA 02801

xx = -100:10:100;
yy = (xx.^2)+(2*xx)+1;

plot(xx,yy,'red');

xlabel('axonas x');
ylabel('axonas y');
title('Grafima');