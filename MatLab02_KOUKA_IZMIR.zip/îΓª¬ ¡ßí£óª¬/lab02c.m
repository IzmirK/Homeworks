%Strogulopoihsh
%IZMIR KOUKA 02801

dianisma = pi:0.34:(2*pi); %evala 0.34 gia na vgalei akrivos 10 stoixeia
fprintf('Arxika: %f\n', dianisma);

dianisma = round(dianisma, 3); %strogulopoihsh gia ta 3 dekadika
fprintf('Strogulopoihmena: %f\n', dianisma);