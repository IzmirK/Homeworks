%Esoteriko ginomeno
%IZMIR KOUKA 02801

dianismarow = 1:1:10;

dianismacol = (10:1:20)';   %antistrefw gia na mporesw na poll/sw

esoterikogin = dianismarow .* dianismacol;

fprintf('%d\n', esoterikogin);