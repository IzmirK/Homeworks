%Grafhma me hmhtono
%IZMIR KOUKA 02801

xx = (2*(1:200))'; %dhmiourgw to 2*k, k = 1-200
yy = sin(2*(xx.^2) + 5); %dianisma ths yy

plot(xx,yy,'black', xx,yy,'red*'); %mavrh gramh

xlabel('xx(k)'); 
ylabel('yy(k)');

title('Grafima hmhtonou');