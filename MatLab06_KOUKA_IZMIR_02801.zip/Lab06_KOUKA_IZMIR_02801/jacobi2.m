%% H synarthsh ayth ylopoiei thn epanalhptikh me8odos Jacobi
%% Kaleite me [sol err it] = jacobi2(a, x0, b, tol, maxiter), opou 
%% a = pinakas nxn, b = deksio melos 
%% x0 = arxikh proseggish ths lyshs, dianisma nx1 
%% tol = megisto apodekto sfalma sthn me8odo,  
%% maxiter = megistos ari8mos epanalhpsewn
%% sol = oles oi proseggistikes lyseis toy systhmatos
%% err = oles oi normes twn diaforwn twn diadoxikwn proseggisewn ths me8odou
%% iter = plh8os epnalhpsewn pou eginan
%%
%% xold - dianisma nx1
%% xnew - dianisma nx1
%% sol - pinakas n x iter
%% err - dianisma 1 x iter

%% yota@uth.gr

function [sol, err, it] = jacobi2(a , x0, b, tol, maxiter)

xold = x0;
error = tol + 1;
iter = 0;
d = diag(a)      %  diagonio meros tou pinaka A
mat = (-a + diag(d))  % -(L+U) pinakas nxn
while (iter < maxiter & error > tol)
  xnew = ((b - mat*xold)./d);
  error = norm(xnew - xold);
  xold = xnew;
  iter = iter + 1;
  err(iter) = error;
  sol(:,iter)= xnew;
%   fprintf('Sthn %d epanalhpsh h norma ths diaforas twn diadoxikwn proseggisewn einai %12.8f . \n',...
%       iter,error );
  plot(iter,log10(error), 'r*');
end
%title('Jacobi iterations');
it = iter; 
end
