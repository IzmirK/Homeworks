x = linspace(-7, 7);

f = (sin(x) ./ (1+(x.^2)));
g = (1-(((x.^2) .* sin(x)) / 10));

hold on
plot(x)
plot(f)
plot(g)
title('GRAFHMA 2 SYNARTHSEWN')
xlabel('x')
ylabel('f(x), g(x)')
legend('x', 'f(x)', 'g(x)')
hold off