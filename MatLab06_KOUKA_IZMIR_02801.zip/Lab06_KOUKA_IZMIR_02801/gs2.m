%% H synarthsh ayth ylopoiei thn epanalhptikh me8odo gauss-seidel
%% Kaleite me [sol err it] = gs2(a, x0, b, tol, maxiter), opou 
%% a = pinakas, b = deksio melos, 
%% x0 = arxikh proseggish ths lyshs,
%% tol = megisto apodekto sfalma sthn me8odo,  
%% maxiter = megistos ari8mos epanalhpsewn
%% sol = oles oi proseggistikes lyseis toy systhmatos
%% err = oles oi normes twn diaforwn twn diadoxikwn proseggisewn ths me8odou
%% iter = plh8os epnalhpsewn pou eginan
%%
%% yota@uth.gr

function [sol, err, it] = gs2(a , x0, b, tol, maxiter)

xold = x0;
error = tol + 1;
iter = 0;
mat_left = tril(a);
mat_right = (mat_left - a);
while (iter < maxiter && error > tol)
  xnew = (mat_left \ (b - mat_right * xold));
  error = norm(xnew - xold);
  xold = xnew;
  iter = iter + 1;
  err(iter) = error;
  sol(:,iter)= xnew;
%   fprintf('Sthn %d epanalhpsh h norma ths diaforas twn diadoxikwn proseggisewn einai %12.8f . \n',...
%       iter,error );
  plot(iter,[log10(error)], 'g*');
end
%title('Gauss-Seidel iterations');
it = iter; 

end