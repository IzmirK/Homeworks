%% Lyste me oles tis epanalhptikes me8odous to parakatw systhma kai melethste tis idiothtes twn me8odwn
%% ws pros to sfalma, to ypoloipo, to plh8os epanalhpsevn kai to xrono ana epanalhpsh kai synolika.
%%
%% Ylopoihste mia synarthsh poy 8a kaleitai [a, errors, res] = test_jac_gs(n)
%% - Orisma eisagwghs h diastash toy pinaka, n (xrhsimopoihste times n=50, n=100, n=1000).
%% - Dhmioyrgeiste ton pinaka a ( nxn ) wste na einai o pentadiagvnios poy perigrafetai stin ekfonisi
%% - ftiakste to deksi meros ths a*x= b, wste to x (h lysh toy systhmatos) na einai dianysma me monades
%%
%% - sto prwto meros symplhrwste th jacobi2 swsta kai xrhsimopoihste thn gia na lysete to systhma
%%
%% - sto deytero meros symplhrwste th gs2 swsta kai xrhsimopoihste thn gia na lysete to systhma
%%
%% - sto dianysma (grammh) errors, prepei na apo8hkeysete ta sfalmata twn me8odwn (me thn parapanw seira) apo th 5h epanalhpsh.
%% - omoia gia to dianysma (grammh) res, poy exei ta antistoixa ypoloipa tvn me8odwn (me thn idia seira) apo hn 5h epanalhpsh.
%%
%% - Xrhsimopoihste Eykleidia norma opoy thn xreiasteite.
%%

function [a, errors, res] = test_jac_gs(n)

a = ((5*diag(ones(n,1)))
xstar = ones(n,1);
b = a*xstar;

%% x0 = initial guess for the solution,
%% tol = maximum acceptable error in the method,  
%% maxiter = maximum number of iterations

x0  = zeros(n,1);
maxiter = 50;
tol = 0.5e-5;

figure(1); clf; hold on;
xlabel('iterations');
ylabel('log_{10} of diff on two consecutive approxim., ||.||_2');
hold on;

%% PART 1 - Jacobi
%% Use jacobi2 to solve the system
%% sol_jac = all the iterative approximations of the solution using the Jacobi method
%% err_jac = all the norms of the differences between two consecutive approximations
%% it_jac = the number of iterations that were performed

disp('Solving with Jacobi')
[sol_jac , ~, ~] = jacobi2(a, x0, b, tol, maxiter);

%% Compute the error and residual at the 5th iteration, for Jacobi
errors(1) = norm(xstar-sol_jac(5,:)');
res(1) = norm(a*sol_jac(5,:)'-b);

%% PART 2 - Gauss-Seidel
%% Use gs2 to solve the system
%% sol_gs = all the iterative approximations of the solution using the Gauss-Seidel method
%% err_gs = all the norms of the differences between two consecutive approximations
%% it_gs = the number of iterations that were performed

disp('Solving with Gauss-Seidel')
[sol_gs , ~, ~] = gs2(a, x0, b, tol, maxiter);

%% Compute the error and residual at the 5th iteration, for Gauss-Seidel
errors(2) = norm(xstar-sol_gs(5,:)');
res(2) = norm(a*sol_gs(5,:)'-b);

disp('Mark the position with the mouse where the legend should appear') 
gtext({'\color{red}Jacobi','\color{green}GS'});
hold off;

fprintf('Jacobi: Error norm at the 5th iteration is %12.8f. \n', errors(1));
fprintf('Gauss-Seidel: Error norm at the 5th iteration is %12.8f. \n', errors(2));

end

