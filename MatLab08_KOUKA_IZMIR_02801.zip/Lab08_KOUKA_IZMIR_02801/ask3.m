
syms x y1 y2

y1 = ((x+cos(x))/(2+x^2));
y2 = (1/((x^2)+1));

hold on
fplot(y1)
fplot(y2)
hold off