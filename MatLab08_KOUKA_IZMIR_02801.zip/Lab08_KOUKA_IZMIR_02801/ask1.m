solve((x^4)-7*(x^2)+12 == 0)
vpasolve((x^4)-7*(x^2)+12 == 0)

solve(exp((x^2)-3*x+2) == 2)
vpasolve(exp((x^2)-3*x+2) == 2)

solve((x^2)+1 == 0)
vpasolve((x^2)+1 == 0)