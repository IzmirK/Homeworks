syms x1 x2 x3
[x1, x2, x3]=solve(((2*x1)-(3*x2)+x3)-2, (x1+(2*x2)-x3-4), (3*x1)+x2+(2*x3));
fprintf('x1 is %f, x2 is %f, x3 is %f\n',x1, x2, x3);

syms x y
[x, y]=solve(((x^2)+(y^2)-16), ((x^2)/9)+((y^2)/25)-1);
fprintf('x is %f, y is %f\n', x, y);